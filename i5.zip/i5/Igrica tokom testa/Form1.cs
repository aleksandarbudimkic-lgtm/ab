﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Igrica_tokom_testa
{
    public partial class Form1 : Form
    {
        private int g=0;
        private int x = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar=='w')
            {
                button1.Top -= 90;
            }
            if (e.KeyChar == 's')
            {
                button1.Top += 90;
            }
            if (e.KeyChar == 'a')
            {
                button1.Left -= 90;
            }
            if (e.KeyChar == 'd')
            {
                button1.Left += 90;
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button1.Enabled=true;
            button1.Focus();
            timer1.Start();
            button1.Left = 40;
            button1.Top = 120;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            button2.Top += 5;
            button5.Top += 15;
            button6.Top += 20;
            button7.Top -= 20;
            if (button2.Top >= 500)
                button2.Top = -100;
            if (button2.Bounds.IntersectsWith(button1.Bounds))
                button1.Top += 5;
            if (button5.Top >= 500)
                button5.Top = -100;
            if (button6.Top >= 500)
                button6.Top = -100;
            if (button7.Top <= 0)
                button7.Top = 500;

            if (button4.Bounds.IntersectsWith(button1.Bounds)&& !button2.Bounds.IntersectsWith(button1.Bounds))
            {
                timer1.Stop();
                button1.Enabled = false;
            }
            if(button1.Bounds.IntersectsWith(button5.Bounds)||button1.Bounds.IntersectsWith(button6.Bounds)||
                button1.Bounds.IntersectsWith(button7.Bounds))
            {
                timer1.Stop();
                button1.Enabled = false;
            }

            if(button1.Left>=800)
            {
                button1.Left = 40;
                button1.Top = 120;
                x++;
                label1.Text = "" + x.ToString();
                MessageBox.Show("BRAVO BAJOO ZAVRSIO SI! osvojio si 500dinara free beta mozes da podignes u svakoj mozzart radionici");
            }
            
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace igrica_3
{
    public partial class Form1 : Form
    {
        private int b=1;
        private int g=0;
        public Form1()
        {
            InitializeComponent();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button4.Height = 1000;
            button6.Height = 1000;
            button9.Height = 1000;
            Random x = new Random();
            int visina = x.Next(0, 260) + 30;
            button3.Height = visina;
            button7.Height = 1000;
            button8.Height = 1000;
            button4.Top = visina + 100;
            button3.Left = 800;
            button4.Left = 800;
            button7.Left = 800;
            button7.Top = visina;
            
            visina = x.Next(0, 260) + 30;
            button5.Height = visina;
            button6.Top = visina + 100;
            button5.Left = button3.Left + 300;
            button6.Left = button4.Left + 300;
            button8.Left = button7.Left + 300;
            button8.Top = visina;

            visina = x.Next(0, 260) + 30;
            button11.Height = visina;
            button10.Top = visina + 100;
            button11.Left = button5.Left+300;
            button10.Left = button5.Left+300;
            button9.Left = button5.Left+300;
            button9.Top = visina;
            
            button10.Height = 1000;

            timer1.Start();
            timer2.Start();
            timer3.Start();
            button1.Enabled = true;
            button1.Focus();
            b = 1;
            label1.Text = "0";
            label2.Text = "0";
        }

        private void button1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == 'w' || e.KeyChar == ' ') && button1.Top > panel2.Top-panel1.Height+20)
            {
                button1.Top -= 20;
                b = 1;
            }
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            button3.Left -= 5;
            button4.Left = button3.Left;
            button7.Left = button3.Left + button3.Width;
            if (button3.Left<-10)
            {
                Random x = new Random();
                int visina = x.Next(0, 260) + 30;
                button3.Height = visina;
                button4.Top = visina + 100;
                button3.Left = 800;
                button4.Left = 800;
                button7.Left = 800;
            }
            button5.Left -= 5;
            button6.Left = button5.Left;
            button8.Left = button5.Left + button5.Width;
            if (button5.Left < -10)
            {
                Random x = new Random();
                int visina = x.Next(0, 260) + 30;
                button5.Height = visina;
                button6.Top = visina + 100;
                button5.Left = button3.Left + 400;
                button6.Left = button4.Left + 400;
                button8.Left = button7.Left + 400;
            }
            
            button11.Left -= 5;
            button10.Left = button11.Left;
            button9.Left = button11.Left + button11.Width;
            if (button11.Left < -10)
            {
                Random x = new Random();
                int visina = x.Next(0, 260) + 30;
                button11.Height = visina;
                button10.Top = visina + 100;
                button11.Left = button5.Left + 400;
                button10.Left = button6.Left+400;
                button9.Left = button8.Left+400;
            }
            if (button1.Bounds.IntersectsWith(button7.Bounds) ||
               button1.Bounds.IntersectsWith(button8.Bounds))
            {
                if (g == 0)
                {
                    int poeni = Convert.ToInt32(label2.Text);
                    poeni++;
                    label2.Text = Convert.ToString(poeni);
                    g = 1;
                    timer4.Start();
                }
            }

            if (button1.Bounds.IntersectsWith(button3.Bounds) ||
                button1.Bounds.IntersectsWith(button4.Bounds) ||
                button1.Bounds.IntersectsWith(button5.Bounds) ||
                button1.Bounds.IntersectsWith(button6.Bounds) ||
                button1.Bounds.IntersectsWith(button11.Bounds) ||
                button1.Bounds.IntersectsWith(button10.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
                button1.Enabled = false;
                MessageBox.Show("GAME OVER");
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            button1.Top += 1 + b;
            if(b<20)b +=b;
            
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            int vreme = Convert.ToInt32(label1.Text);
            vreme++;
            label1.Text = Convert.ToString(vreme);
           
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            if (g == 1)
            {
                g = 0;
                timer4.Stop();
            }
        }
    }
}
